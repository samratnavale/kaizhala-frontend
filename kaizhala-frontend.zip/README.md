# Kaizhala Frontend

This is the frontend for the Kaizhala secure messaging app.

## To Deploy

1. Upload this project to GitHub
2. Connect it to [Vercel](https://vercel.com)
3. Vercel will auto-detect the setup (React + Vite)
4. Click Deploy
